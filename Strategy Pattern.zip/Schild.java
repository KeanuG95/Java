public class Schild implements Defense {
    @Override
    public void defend() {
        System.out.println("Angriff mit dem Schild abgewehrt!\n");
    }
}

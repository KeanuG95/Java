public class Pfeil implements Attack{
    @Override
    public void attack() {
        System.out.println("Bogen gespannt, Pfeil abgeschossen, Gegner getroffen!\n");
    }
}

public class Bogenschuetze implements Character {

    Attack currentStrat = new Pfeil();
    Defense defense = new Ausweichen();

    @Override
    public void performAtk(Attack as) {
        currentStrat = as;
    }

    @Override
    public void performDef(Defense d) {
        defense = d;
    }

    public void attackB() {
        currentStrat.attack();
    }

    public void defenseB() {
        defense.defend();
    }
}

public class SchwertAngriff implements Attack {
    @Override
    public void attack() {
        System.out.println("Ein wirksamer Nahangriff mit dem Schwert!\n");
    }
}

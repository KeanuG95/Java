public class Ausweichen implements Defense {
    @Override
    public void defend() {
        System.out.println("Feindlichem Angriff erfolgreich ausgewichen!\n");
    }
}

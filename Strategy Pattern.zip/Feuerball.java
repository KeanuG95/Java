public class Feuerball implements Attack {
    @Override
    public void attack() {
        System.out.println("Ein effizienter Fernangriff mit dem Feuerball!\n");
    }
}

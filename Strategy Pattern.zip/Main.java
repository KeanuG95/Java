public class Main {
    public static void main(String[] args) {


        Krieger krieger = new Krieger();
        Magier magier = new Magier();
        Bogenschuetze bogenschuetze = new Bogenschuetze();
        krieger.attackK();
        krieger.performAtk(new Feuerball());
        krieger.attackK();
        magier.attackM();
        bogenschuetze.attackB();
        bogenschuetze.performAtk(new SchwertAngriff());
        bogenschuetze.attackB();
        krieger.defenseK();
        magier.defenseM();
        bogenschuetze.defenseB();
        krieger.performDef(new Ausweichen());
        krieger.defenseK();
    }
}

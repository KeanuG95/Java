public class Magier implements Character {

    Attack currentStrat = new Feuerball();
    Defense defense = new MagischerSchild();

    @Override
    public void performAtk(Attack as) {

    }

    @Override
    public void performDef(Defense d) {
        defense = d;
    }

    public void attackM() {
        currentStrat.attack();
    }

    public void defenseM() {
        defense.defend();
    }
}

public interface Attack {

    void attack();
}

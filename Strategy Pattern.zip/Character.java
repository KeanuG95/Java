public interface Character {

    void performAtk(Attack as);
    void performDef(Defense d);
}

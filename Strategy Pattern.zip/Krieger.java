public class Krieger implements Character {

    Attack currentStrat = new SchwertAngriff();
    Defense defense = new Schild();

    @Override
    public void performAtk(Attack as) {
        currentStrat = as;
    }

    @Override
    public void performDef(Defense d) {
        defense = d;
    }

    public void attackK() {
        currentStrat.attack();
    }

    public void defenseK() {
        defense.defend();
    }
}

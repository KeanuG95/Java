public interface Defense {

    void defend();
}

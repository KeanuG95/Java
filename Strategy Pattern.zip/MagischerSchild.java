public class MagischerSchild implements Defense {
    @Override
    public void defend() {
        System.out.println("Eingehender Schaden wird durch einen magischen Schild reduziert!\n");
    }
}

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Mitarbeiter {

    public static final ArrayList<Mitarbeiter> mitarbeiterListe = new ArrayList<>();
    int id;
    String vorname;
    String nachname;
    double gehalt;
    Blob bild;

    public Mitarbeiter(int id, String vorname, String nachname, double gehalt, Blob bild) {
        this.id = id;
        this.vorname = vorname;
        this.nachname = nachname;
        this.gehalt = gehalt;
        this.bild = bild;
    }

    public static boolean holeMA() throws SQLException {
        Statement statement = DBConnector.getConnection().createStatement();
        ResultSet rs = statement.executeQuery("select * from personal");
        while (rs.next()) {
            mitarbeiterListe.add(new Mitarbeiter(rs.getInt(1), rs.getString(2),
                    rs.getString(3), rs.getDouble(4), rs.getBlob(5)));
        } return true;
    }

    @Override
    public String toString() {
        return "Mitarbeiter " +
                "id = " + id +
                ", vorname = " + vorname +
                ", nachname = " + nachname +
                ", gehalt = " + gehalt + "$" +
                ", bild = " + bild;
    }
}



import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {

        try {
            System.out.println((Mitarbeiter.holeMA()) ? "Datentransfer erfolgreich" : "Datentransfer nicht erfolgreich");
            System.out.println();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        for (Mitarbeiter tmp : Mitarbeiter.mitarbeiterListe) {
            System.out.println(tmp);
        }
    }
}


import java.sql.*;

public class DBConnector {

    static String connectionString = "jdbc:mysql://localhost:3306/personal";

    static Connection connection;

    private DBConnector() {}

    public static Connection getConnection() {


        try {
            connection = DriverManager.getConnection(connectionString, "root", "");

        } catch (SQLException e) {
            e.printStackTrace();
        } return connection;
    }
}


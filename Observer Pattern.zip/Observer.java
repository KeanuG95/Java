public interface Observer {

    void update(Erieignisquelle quelle);
}

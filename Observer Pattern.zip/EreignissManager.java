import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EreignissManager {
    public static void main(String[] args) {

        Kamera kamera = new Kamera("Kamera Hotel Foyer", "Bewegung im Bereich");
        Protokoll protokoll = new Protokoll();
        kamera.addObserver(protokoll);
        kamera.bewegungssensorAktivieren();
        Kamera kamera2 = new Kamera("Kamera Parkplatz", "Sabotagealarm");
        kamera2.addObserver(protokoll);
        kamera2.bewegungssensorAktivieren();

        List<String> nachrichten = Arrays.asList("Treffpunkt am Bahnhof um 22:00 Uhr",
                "Das Ziel ist festgelegt. Plan erfolgt später.",
                "Wir treffen uns um 21:30, alle müssen da sein!!!",
                "Überwachung startet um 19:00",
                "Plan ist durchgesickert. Zieländerung notwendig!");

        List<String> trigger = Arrays.asList("Bruch", "Beute", "Bank", "Plan", "Ziel");

        SMSUeberwachen panzerKnackerEde = new SMSUeberwachen("Panzerknacker Ede", "Keyword benutzt bei SMS", trigger);

        panzerKnackerEde.addObserver(protokoll);
        panzerKnackerEde.nachrichtSenden("Ihr stricher heute gehe ich auf die Bank und hole mir die fat stacks ab");

        for (String tmp : nachrichten) {
            panzerKnackerEde.nachrichtSenden(tmp);
        }
        protokoll.protokollAusgeben();
    }
}

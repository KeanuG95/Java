import java.util.ArrayList;
import java.util.List;

public class SMSUeberwachen extends Erieignisquelle {

    List<String> trigger = new ArrayList<String>();

    public SMSUeberwachen(String id, String message, List<String> trigger) {
        super(id, message);
        this.trigger = trigger;
    }

    public void nachrichtSenden(String nachricht) {
        for (String tmp : trigger) {
            if (nachricht.contains(tmp)){
                alert();
            }
        }
    }
}

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Protokoll implements Observer {

    List<String> ereignisListe = new ArrayList<>();

    @Override
    public void update(Erieignisquelle quelle) {
        ereignisListe.add(LocalDateTime.now() + " " + quelle.message + " " + quelle.id + "\n");
    }

    public void protokollAusgeben() {
        for (String tmp : ereignisListe) {
            System.out.println(tmp);
        }
    }
}

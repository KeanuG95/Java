import java.util.ArrayList;
import java.util.List;

public abstract class Erieignisquelle {

    public String id;
    public String message;
    List<Observer> beobachter = new ArrayList<>();

    public Erieignisquelle(String id, String message) {
        this.id = id;
        this.message = message;
    }

    public void addObserver(Observer obs) {
        beobachter.add(obs);
    }

    public void removeObserver(Observer obs) {
        beobachter.remove(obs);
    }

    public void notifyObservers() {
        for (Observer tmp : beobachter) {
            tmp.update(this);
        }
    }

    void alert() {
        notifyObservers();
    }

}

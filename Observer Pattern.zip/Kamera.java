public class Kamera extends Erieignisquelle {

    public Kamera(String id, String message) {
        super(id, message);
    }

    void bewegungssensorAktivieren() {
        alert();
    }
}
